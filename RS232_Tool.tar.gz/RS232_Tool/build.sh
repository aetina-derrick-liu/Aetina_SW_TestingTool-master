gcc rs232_send.c -o rs232_send
gcc rs232_recv.c -o rs232_recv
